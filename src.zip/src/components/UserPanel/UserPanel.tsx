import styles from './UserPanel.module.scss';

export const UserPanel = () => {
    return (
        <div className={styles.user}>
            <div className={styles.user__header}>
                
            </div>
        </div>
    )
}