import { useDispatch, useSelector } from 'react-redux';
import { fetchUser } from '../../store/userSlice';
import { AppDispatch, RootState } from '../../store/store';
import { SearchInput } from '../SearchInput/SearchInput';

import { home, avatar, styles, bot, useEffect, useNavigate } from './index'

export const Header = () => {
    const dispatch = useDispatch<AppDispatch>();
    const navigate = useNavigate();
    const { user, status } = useSelector((state: RootState) => state.user);

    useEffect(() => {
        if (!user && status !== 'loading') {
            dispatch(fetchUser())
                .unwrap()
                .catch(() => {
                    navigate('/auth', { replace: true });
                });
        }
    }, [dispatch, user, status]);

    return (
        <header className={styles.header}>
            <div className={styles.header__left}>
                <div className={styles.header__user}>
                    <div className={styles.icon__container}>
                        {user?.avatar ? (
                            <img
                                src={`data:image/jpeg;base64,${user.avatar}`}
                                alt="user icon"
                                className={styles.user__icon}
                            />
                        ) : (
                            <img
                                src={avatar}
                                alt="user icon"
                                className={styles.user__icon}
                            />
                        )}
                    </div>
                    <div className={styles.header__username}>
                        <span className={styles.full__name}>{user?.full_name}</span>
                        <span className={styles.user__name}>{`@${user?.username}`}</span>
                    </div>
                </div>
            </div>
            <SearchInput />
            <ul className={styles.header__list}>
                <li className={styles.header__item}>
                    <a href="/" className={styles.header__button}>
                        <img src={home} alt="home_page" className={styles.header__icon} />
                    </a>
                </li>
                <li className={styles.header__item}>
                    <a href="https://t.me/CloudgramWeb_bot" target="_blank" className={styles.header__button}>
                        <img src={bot} alt="bot_link" className={styles.header__icon} />
                    </a>
                </li>
            </ul>
        </header>
    );
};
