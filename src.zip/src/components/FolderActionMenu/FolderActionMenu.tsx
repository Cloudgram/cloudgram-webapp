import styles from './FolderActionMenu.module.scss'
import { FC } from 'react'

interface ActionMenuProps {
    onDelete: () => void
    onDownload?: () => void
    menuRef: React.RefObject<HTMLDivElement>
}

export const FolderActionMenu: FC<ActionMenuProps> = ({ onDelete, menuRef }) => {
    return (
        <div className={styles.actionMenu} ref={menuRef}>
            <button className={styles.actionMenu__button} onClick={onDelete}>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024">
                    <path fill="currentColor" fillOpacity=".15" d="M292.7 840h438.6l24.2-512h-487z" />
                    <path fill="currentColor" d="M864 256H736v-80c0-35.3-28.7-64-64-64H352c-35.3 0-64 28.7-64 64v80H160c-17.7 0-32 14.3-32 32v32c0 4.4 3.6 8 8 8h60.4l24.7 523c1.6 34.1 29.8 61 63.9 61h454c34.2 0 62.3-26.8 63.9-61l24.7-523H888c4.4 0 8-3.6 8-8v-32c0-17.7-14.3-32-32-32m-504-72h304v72H360zm371.3 656H292.7l-24.2-512h487z" />
                </svg>
                Удалить
            </button>
        </div>
    )
}