import { Link, useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import styles from './FolderPath.module.scss';
import { getFolders } from '../FoldersList';

interface Folder {
    id: string;
    title: string;
    folder_id: string | null;
}

export const FolderPath = () => {
    const { folderId = '0' } = useParams();
    const [path, setPath] = useState<Folder[]>([]);

    useEffect(() => {
        const fetchPath = async () => {
            let currentFolderId = folderId;
            const newPath: Folder[] = [];

            
            while (currentFolderId) {
                const folderDetails = await getFolders(currentFolderId); 
                newPath.unshift({
                    id: folderDetails.id,
                    title: folderDetails.title,
                    folder_id: folderDetails.folder_id,
                });
                currentFolderId = folderDetails.folder_id;
            }

            setPath(newPath);
        };

        fetchPath();
    }, [folderId]);

    return (
        <nav className={styles.breadcrumbs}>
            <ul className={styles.breadcrumbs__list}>
                {folderId !== '0' && (
                    <>
                        <Link to={`/folder/0`} className={styles.breadcrumbs__link}>
                            Главная
                        </Link>
                        <svg width="24px" height="24px" viewBox="0 0 24 24" focusable="false" fill="currentColor">
                            <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                        </svg>
                    </>

                )}
                {path.map((folder, index) => (
                    <li key={folder.id} className={styles.breadcrumbs__item}>
                        {folderId === '0' ? (
                            <span className={styles.breadcrumbs__title}>Главная</span>
                        ) : (
                            <Link to={`/folder/${folder.id}`} className={styles.breadcrumbs__link}>
                                {`${folder.title}`}
                            </Link>
                        )}
                        {index < path.length - 1 && (
                            <svg width="24px" height="24px" viewBox="0 0 24 24" focusable="false" fill="currentColor">
                                <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                            </svg>
                        )}
                    </li>
                ))}
            </ul>
        </nav>
    );
};