import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { UserType } from '../types/UserType';
import { getUser } from '../api/User';

interface UserState {
    user: UserType | null;
    status: 'idle' | 'loading' | 'succeeded' | 'failed';
    error: string | null;
}

const initialState: UserState = {
    user: null,
    status: 'idle',
    error: null,
};

// Асинхронный thunk для получения данных пользователя
export const fetchUser = createAsyncThunk<UserType, void, { rejectValue: string }>(
    'user/fetchUser',
    async (_, { rejectWithValue }) => {
        try {
            const user = await getUser();
            return user;
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        } catch (error) {
            return rejectWithValue('Сессия истекла или была заблокирована');
        }
    }
);

const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        logout(state) {
            state.user = null;
            state.status = 'idle';
            state.error = null;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchUser.pending, (state) => {
                state.status = 'loading';
                state.error = null;
            })
            .addCase(fetchUser.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.user = action.payload;
            })
            .addCase(fetchUser.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload || 'Ошибка авторизации';
            });
    },
});

export const { logout } = userSlice.actions;
export default userSlice.reducer;