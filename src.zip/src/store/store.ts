import { configureStore } from '@reduxjs/toolkit';
import pathReducer from './pathSlice';
import userReducer from './userSlice';

export const store = configureStore({
    reducer: {
        path: pathReducer,
        user: userReducer,
    },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;