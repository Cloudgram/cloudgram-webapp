import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface Folder {
    id: string;
    title: string;
    folder_id: string | null;
}

interface PathState {
    path: Folder[];
}

const initialState: PathState = {
    path: [],
};

const pathSlice = createSlice({
    name: "path",
    initialState,
    reducers: {
        setPath(state, action: PayloadAction<Folder[]>) {
            state.path = action.payload;
        },
        clearPath(state) {
            state.path = [];
        },
    },
});

export const { setPath, clearPath } = pathSlice.actions;
export default pathSlice.reducer;